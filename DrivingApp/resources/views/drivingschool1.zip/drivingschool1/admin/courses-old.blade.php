@extends($isAjax ?? false ? 'layouts.ajax' : 'layouts.app')

@section('title', 'Courses Management')

@section('content')
@php
    $school = $school ?? $currentSchool ?? null;
    $schoolName = $school->name ?? 'Driving School';
@endphp

<style>
    .courses-container {
        padding: 20px;
        margin: 20px auto;
        max-width: 1600px;
    }
    
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        padding-bottom: 15px;
        border-bottom: 2px solid #667eea;
    }
    
    .page-title {
        font-size: 2rem;
        color: #333;
        margin: 0;
    }

    .page-title {
        font-size: 2rem;
        color: #333;
        margin: 0;
    }
    
    /* Action Bar */
    .action-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
    }
    
    .search-box {
        position: relative;
        flex: 1;
        max-width: 400px;
    }
    
    .search-box input {
        width: 100%;
        padding: 10px 40px 10px 15px;
        border: 2px solid #e1e5e9;
        border-radius: 8px;
        font-size: 0.95rem;
        transition: border-color 0.3s;
    }
    
    .search-box input:focus {
        outline: none;
        border-color: #667eea;
    }
    
    .search-box::after {
        content: "🔍";
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
    }
    
    .btn-create {
        padding: 10px 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: 500;
        cursor: pointer;
        transition: transform 0.2s, box-shadow 0.2s;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .btn-create:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    }

.courses-filters {
    display: flex;
    gap: 20px;
    margin-bottom: 30px;
    flex-wrap: wrap;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.filter-group label {
    font-weight: 600;
    color: #555;
    font-size: 0.9rem;
}

.courses-filters {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.filter-group {
    display: flex;
    align-items: center;
    gap: 10px;
}

.filter-group label {
    font-weight: 600;
    color: #555;
    font-size: 0.95rem;
}

.form-select {
    padding: 8px 12px;
    border: 2px solid #e1e5e9;
    border-radius: 8px;
    font-size: 0.95rem;
    transition: border-color 0.3s;
    background: white;
    cursor: pointer;
}

.form-select:focus {
    outline: none;
    border-color: #667eea;
}

/* Table Styles */
.table-container {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

table {
    width: 100%;
    border-collapse: collapse;
}

thead {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

th {
    padding: 15px;
    text-align: left;
    font-weight: 600;
    font-size: 0.95rem;
}

td {
    padding: 15px;
    border-bottom: 1px solid #f1f3f5;
}

tbody tr {
    transition: background-color 0.2s;
}

tbody tr:hover {
    background-color: #f8f9fa;
}

.status-badge {
    display: inline-block;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 500;
}

.status-active {
    background: #d4edda;
    color: #155724;
}

.status-inactive {
    background: #f8d7da;
    color: #721c24;
}

.status-archived {
    background: #e2e3e5;
    color: #383d41;
}

.btn-action {
    padding: 6px 12px;
    margin: 0 3px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 0.9rem;
    transition: all 0.2s;
}

.btn-edit {
    background: #ffc107;
    color: #000;
}

.btn-edit:hover {
    background: #ffb300;
    transform: scale(1.05);
}

.btn-delete {
    background: #dc3545;
    color: white;
}

.btn-delete:hover {
    background: #c82333;
    transform: scale(1.05);
}

.success-alert {
    background: #d1fae5;
    color: #065f46;
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-left: 4px solid #10b981;
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #999;
}

.empty-state-icon {
    font-size: 4rem;
    margin-bottom: 20px;
}

.empty-state-text {
    font-size: 1.2rem;
    color: #666;
}

/* Modal Styles */
.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    font-size: 0.9rem;
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 14px 28px;
    font-size: 1rem;
    font-weight: 600;
    border-radius: 8px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.25);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35);
}

.btn-secondary { 
    background: linear-gradient(135deg, #6c757d 0%, #5a6268 100%);
    color: white;
    padding: 14px 28px;
    font-size: 1rem;
    font-weight: 600;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.btn-secondary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(108, 117, 125, 0.3);
}

.btn-success { background: #28a745; color: white; }
.btn-danger { background: #dc3545; color: white; }
.btn-sm { padding: 8px 16px; font-size: 0.85rem; }

.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.7);
    backdrop-filter: blur(8px);
    z-index: 2000;
    align-items: center;
    justify-content: center;
}

.modal.show { display: flex; }

.modal-content {
    background: white;
    border-radius: 16px;
    width: 95%;
    max-width: 1000px;
    max-height: 90vh;
    display: flex;
    flex-direction: column;
    box-shadow: 0 25px 50px rgba(0,0,0,0.4);
}

.modal-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 28px 32px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-shrink: 0;
}

.modal-header h2 {
    margin: 0;
    font-size: 1.75rem;
    font-weight: 600;
}

.close-btn {
    background: rgba(255,255,255,0.2);
    border: none;
    color: white;
    font-size: 1.75rem;
    cursor: pointer;
    width: 36px;
    height: 36px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
}

.close-btn:hover {
    background: rgba(255,255,255,0.3);
}

.form-group {
    padding: 0;
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #1a202c;
    font-size: 0.95rem;
}

.form-control, .form-select {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    font-size: 0.95rem;
    transition: all 0.2s ease;
    background: #fff;
}

.form-control:focus, .form-select:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.modal-actions {
    padding: 24px 32px;
    background: #f8f9fa;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    border-radius: 0 0 16px 16px;
    flex-shrink: 0;
}

.modal-tabs {
    display: flex;
    background: #f8f9fa;
    padding: 0;
    margin: 0;
    border-bottom: 2px solid #e2e8f0;
    flex-shrink: 0;
}

.tab-btn {
    padding: 15px 25px;
    background: transparent;
    border: none;
    cursor: pointer;
    font-weight: 500;
    color: #666;
    border-bottom: 3px solid transparent;
    transition: all 0.3s;
}

.tab-btn:hover {
    color: #667eea;
    background: rgba(102, 126, 234, 0.05);
}

.tab-btn.active {
    color: #667eea;
    border-bottom-color: #667eea;
    background: white;
}

.tab-content {
    display: none;
    padding: 32px;
    background: #fff;
    overflow-y: auto;
    flex: 1;
    min-height: 0;
}

.tab-content.active {
    display: block;
}

.schedule-builder {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 8px;
}

.schedule-item {
    background: white;
    padding: 15px;
    margin: 10px 0;
    border-radius: 6px;
    border-left: 4px solid #667eea;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.schedule-item-details {
    flex: 1;
}

.schedule-item-actions button {
    background: #dc3545;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    cursor: pointer;
}

.date-badge {
    display: inline-block;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 8px 12px;
    border-radius: 6px;
    margin: 4px;
    cursor: pointer;
    transition: all 0.3s;
    font-size: 0.9rem;
    font-weight: 500;
}

.date-badge:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(102, 126, 234, 0.3);
    background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
}

.time-slot-item {
    background: white;
    padding: 10px 15px;
    margin: 8px 0;
    border-radius: 6px;
    border-left: 3px solid #28a745;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.time-slot-item button {
    background: #dc3545;
    color: white;
    border: none;
    padding: 4px 10px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.85rem;
}

@media (max-width: 768px) {
    .courses-grid { grid-template-columns: 1fr; }
    .form-row { grid-template-columns: 1fr; }
    .course-actions { flex-direction: column; }
    .course-actions .btn { width: 100%; }
    .modal-tabs { flex-direction: column; }
    .tab-btn { width: 100%; }
}
</style>

<div class="courses-container">
    <!-- Page Header -->
    <div class="page-header">
        <h1 class="page-title">Courses Management</h1>
    </div>
    
    @if(session('success'))
        <div class="success-alert">{{ session('success') }}</div>
    @endif
    
    <!-- Action Bar -->
    <div class="action-bar">
        <div class="search-box">
            <input type="text" id="courseSearch" placeholder="Search courses by title or type..." onkeyup="filterCourses()">
        </div>
        <button class="btn-create" onclick="createCourse()">
            ➕ Add New Course
        </button>
    </div>
    
    <!-- Filters -->
    <div class="courses-filters">
        <div class="filter-group">
            <label>Status:</label>
            <select id="statusFilter" class="form-select" onchange="filterCourses()">
                <option value="">All</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="archived">Archived</option>
            </select>
        </div>
        <div class="filter-group">
            <label>Type:</label>
            <select id="typeFilter" class="form-select" onchange="filterCourses()">
                <option value="">All</option>
                <option value="standard">Standard</option>
                <option value="intensive">Intensive</option>
                <option value="refresher">Refresher</option>
            </select>
        </div>
    </div>
    
    <!-- Table View -->
    <div class="table-container">
        @if($courses->count() > 0)
            <table id="coursesTable">
                <thead>
                    <tr>
                        <th>Course Title</th>
                        <th>Type</th>
                        <th>Duration</th>
                        <th>Price</th>
                        <th>Max Students</th>
                        <th>Enrolled</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($courses as $course)
                    <tr data-status="{{ $course->status }}" data-type="{{ $course->type }}">
                        <td><strong>{{ $course->title }}</strong></td>
                        <td>{{ ucfirst($course->type) }}</td>
                        <td>{{ $course->duration_hours }} hours</td>
                        <td>₱{{ number_format($course->price, 2) }}</td>
                        <td>{{ $course->max_students ?? 'Unlimited' }}</td>
                        <td>
                            {{ $course->enrolledStudentsCount() }}
                            @if($course->max_students && $course->isFull())
                                <span class="status-badge status-inactive">FULL</span>
                            @endif
                        </td>
                        <td>
                            <span class="status-badge status-{{ $course->status }}">
                                {{ ucfirst($course->status) }}
                            </span>
                        </td>
                        <td>
                            <button class="btn-action btn-edit" onclick="editCourse({{ $course->id }})">Edit</button>
                            <button class="btn-action btn-delete" onclick="deleteCourse({{ $course->id }})">Delete</button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        @else
            <div class="empty-state">
                <div class="empty-state-icon">📚</div>
                <div class="empty-state-text">No courses found</div>
            </div>
        @endif
    </div>
</div>

<!-- Course Modal with Tabs -->
<div id="courseModal" class="modal">
    <div class="modal-content" style="max-width: 1200px; width: 95%;">
        <div class="modal-header">
            <h2 id="modalTitle">Add Course</h2>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        
        <!-- Tab Navigation -->
        <div class="modal-tabs">
            <button type="button" class="tab-btn active" onclick="switchTab('courseInfo')">Course Info</button>
            <button type="button" class="tab-btn" onclick="switchTab('schedules')" id="scheduleTabBtn">Pre-Define Schedules</button>
        </div>

        <!-- Tab Content: Course Info -->
        <div id="courseInfoTab" class="tab-content active">
            <form id="courseForm" onsubmit="saveCourse(event)">
                <input type="hidden" id="courseId">
                <div class="form-group">
                    <label for="title">Course Title *</label>
                    <input type="text" id="title" name="title" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" class="form-control" rows="4"></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="price">Price (₱) *</label>
                        <input type="number" id="price" name="price" class="form-control" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="duration_hours">Duration (hours) *</label>
                        <input type="number" id="duration_hours" name="duration_hours" class="form-control" step="0.5" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="max_students">Max Students (Optional)</label>
                        <input type="number" id="max_students" name="max_students" class="form-control" min="1" placeholder="Leave empty for unlimited">
                        <small style="color: #666; font-size: 0.85rem;">Set maximum enrollment limit (leave blank for no limit)</small>
                    </div>
                    <div class="form-group">
                        <!-- Empty column for grid alignment -->
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="type">Type</label>
                        <select id="type" name="type" class="form-select">
                            <option value="standard">Standard</option>
                            <option value="intensive">Intensive</option>
                            <option value="refresher">Refresher</option>
                            <option value="defensive">Defensive Driving</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status" class="form-select">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="archived">Archived</option>
                        </select>
                    </div>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Course</button>
                </div>
            </form>
        </div>

        <!-- Tab Content: Schedules -->
        <div id="schedulesTab" class="tab-content">
            <div class="schedule-builder">
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="enableBulkSchedule" onchange="toggleBulkSchedule()">
                        <strong>Enable Bulk Schedule Creation (Multiple Dates at Once)</strong>
                    </label>
                </div>

                <!-- Single Date Input -->
                <div id="singleDateSection">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="schedule_date">Date *</label>
                            <input type="date" id="schedule_date" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="schedule_start_time">Start Time *</label>
                            <input type="time" id="schedule_start_time" class="form-control">
                        </div>
                    </div>
                </div>

                <!-- Bulk Date Selection -->
                <div id="bulkDateSection" style="display: none;">
                    <div class="form-group">
                        <label for="bulk_dates">Select Multiple Dates * (Ctrl+Click to select multiple)</label>
                        <div style="background: white; border: 1px solid #ddd; border-radius: 6px; padding: 10px; max-height: 200px; overflow-y: auto;">
                            <input type="date" id="date_picker_helper" class="form-control" onchange="addDateToList()" style="margin-bottom: 10px;">
                            <div id="selectedDatesList" style="display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px;">
                                <small style="color: #999; width: 100%;">Select dates above to add them to the list</small>
                            </div>
                        </div>
                        <small style="color: #666;">Click dates above to add. Click selected dates to remove.</small>
                    </div>
                    
                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="multipleSlotsPerDate" onchange="toggleMultipleSlots()">
                            <strong>Add Multiple Time Slots per Date</strong>
                        </label>
                    </div>

                    <!-- Single Time Slot (Default) -->
                    <div id="singleSlotSection">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="bulk_start_time">Start Time *</label>
                                <input type="time" id="bulk_start_time" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="bulk_end_time">End Time *</label>
                                <input type="time" id="bulk_end_time" class="form-control">
                            </div>
                        </div>
                    </div>

                    <!-- Multiple Time Slots -->
                    <div id="multipleSlotSection" style="display: none;">
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 6px; margin-bottom: 15px;">
                            <h4>Time Slots</h4>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="slot_start_time">Start Time</label>
                                    <input type="time" id="slot_start_time" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="slot_end_time">End Time</label>
                                    <input type="time" id="slot_end_time" class="form-control">
                                </div>
                            </div>
                            <button type="button" class="btn btn-sm btn-primary" onclick="addTimeSlot()">➕ Add Time Slot</button>
                            <div id="timeSlotsList" style="margin-top: 10px;"></div>
                        </div>
                    </div>
                </div>

                <!-- Common Schedule Fields -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="schedule_end_time">End Time *</label>
                        <input type="time" id="schedule_end_time" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="schedule_max_students">Max Students *</label>
                        <input type="number" id="schedule_max_students" class="form-control" value="1" min="1">
                    </div>
                </div>
                <div class="form-group">
                    <label for="schedule_instructor">Assign Instructor (Optional)</label>
                    <select id="schedule_instructor" class="form-select">
                        <option value="">Auto-assign later</option>
                        @foreach($instructors ?? [] as $instructor)
                            <option value="{{ $instructor->id }}">{{ $instructor->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="schedule_notes">Notes (Optional)</label>
                    <textarea id="schedule_notes" class="form-control" rows="2"></textarea>
                </div>
                <button type="button" class="btn btn-success" onclick="addSchedule()">➕ Add Schedule(s)</button>

                <!-- Schedule List -->
                <div id="schedulesList" style="margin-top: 20px; max-height: 300px; overflow-y: auto;">
                    <h4>Added Schedules (<span id="scheduleCount">0</span>)</h4>
                    <div id="schedulesContainer"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const schoolSlug = '{{ $school->slug }}';

window.filterCourses = function() {
    const searchInput = document.getElementById('courseSearch').value.toUpperCase();
    const statusFilter = document.getElementById('statusFilter').value;
    const typeFilter = document.getElementById('typeFilter').value;
    const table = document.getElementById('coursesTable');
    
    if (!table) return;
    
    const rows = table.getElementsByTagName('tr');
    
    for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        const status = row.dataset.status;
        const type = row.dataset.type;
        const text = row.textContent || row.innerText;
        
        const matchesSearch = text.toUpperCase().indexOf(searchInput) > -1;
        const matchesStatus = !statusFilter || status === statusFilter;
        const matchesType = !typeFilter || type === typeFilter;
        
        row.style.display = matchesSearch && matchesStatus && matchesType ? '' : 'none';
    }
}

window.createCourse = function() {
    document.getElementById('modalTitle').textContent = 'Add Course';
    document.getElementById('courseForm').reset();
    document.getElementById('courseId').value = '';
    
    // Reset to first tab
    switchTab('courseInfo');
    
    // Clear schedule arrays
    courseSchedules = [];
    selectedDates = [];
    timeSlots = [];
    renderSelectedDates();
    renderTimeSlots();
    renderSchedules();
    
    document.getElementById('courseModal').classList.add('show');
}

window.editCourse = function(id) {
    fetch(`/${schoolSlug}/admin/courses/${id}`, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to fetch course');
        }
        return response.json();
    })
    .then(data => {
        const course = data.course || data;
        document.getElementById('modalTitle').textContent = 'Edit Course';
        document.getElementById('courseId').value = course.id;
        document.getElementById('title').value = course.title;
        document.getElementById('description').value = course.description || '';
        document.getElementById('price').value = course.price;
        document.getElementById('duration_hours').value = course.duration_hours;
        document.getElementById('max_students').value = course.max_students || '';
        document.getElementById('type').value = course.type || 'standard';
        document.getElementById('status').value = course.status;
        
        // Reset to first tab
        switchTab('courseInfo');
        
        // Clear schedule arrays (edit mode doesn't support pre-loading schedules yet)
        courseSchedules = [];
        selectedDates = [];
        timeSlots = [];
        renderSelectedDates();
        renderTimeSlots();
        renderSchedules();
        
        document.getElementById('courseModal').classList.add('show');
    })
    .catch(error => {
        console.error('Edit error:', error);
        alert('Error loading course: ' + error.message);
    });
}

window.deleteCourse = function(id) {
    if (!confirm('Are you sure you want to delete this course?')) return;
    
    // Get CSRF token
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || 
                     document.querySelector('input[name="_token"]')?.value || '';
    
    if (!csrfToken) {
        alert('Security token missing. Please refresh the page and try again.');
        return;
    }
    
    fetch(`/${schoolSlug}/admin/courses/${id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken,
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        },
        body: JSON.stringify({ _method: 'DELETE' })
    })
    .then(response => {
        console.log('Delete response status:', response.status);
        
        // If response is successful (2xx status), reload page
        if (response.status >= 200 && response.status < 300) {
            return response.json().then(data => {
                console.log('Delete success:', data);
                alert('Course deleted successfully!');
                window.location.reload();
            }).catch(() => {
                // Even if JSON parsing fails, it was successful
                console.log('Course deleted but response parse failed');
                alert('Course deleted successfully!');
                window.location.reload();
            });
        }
        
        // Handle error responses (including 400 for business logic errors)
        return response.json().then(err => {
            console.error('Delete error response:', err);
            throw new Error(err.message || 'Failed to delete course');
        }).catch(parseError => {
            // If we can't parse the error, use a generic message
            if (parseError.message && parseError.message !== 'Failed to delete course') {
                throw parseError; // Re-throw if it's our custom error
            }
            throw new Error(`HTTP ${response.status}: Failed to delete course`);
        });
    })
    .catch(error => {
        console.error('Delete error:', error);
        alert('Error deleting course: ' + error.message);
    });
}

window.closeModal = function() {
    document.getElementById('courseModal').classList.remove('show');
    
    // Reset to first tab when closing
    setTimeout(() => {
        switchTab('courseInfo');
    }, 300); // Wait for modal animation to complete
}

window.saveCourse = function(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const id = document.getElementById('courseId').value;
    const url = id 
        ? `/${schoolSlug}/admin/courses/${id}`
        : `/${schoolSlug}/admin/courses`;
    
    const data = {};
    formData.forEach((value, key) => data[key] = value);
    
    // Add schedules data if any
    if (courseSchedules && courseSchedules.length > 0) {
        data.schedules = courseSchedules;
    }
    
    if (id) data._method = 'PUT';
    
    // Validate required fields
    if (!data.title || !data.price || !data.duration_hours) {
        alert('Please fill in all required fields (Title, Price, Duration)');
        return;
    }
    
    // Get CSRF token
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || 
                     document.querySelector('input[name="_token"]')?.value || '';
    
    if (!csrfToken) {
        console.error('CSRF token not found');
        alert('Security token missing. Please refresh the page and try again.');
        return;
    }
    
    console.log('Saving course:', { url, data, hasSchedules: data.schedules?.length || 0 });
    
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken,
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        console.log('Response status:', response.status);
        
        // If response is successful (2xx status), close modal and reload
        if (response.status >= 200 && response.status < 300) {
            return response.json().then(data => {
                console.log('Success response:', data);
                const scheduleMsg = data.schedules_created > 0 
                    ? ` with ${data.schedules_created} schedule(s)` 
                    : '';
                alert('Course saved successfully' + scheduleMsg + '!');
                closeModal();
                setTimeout(() => {
                    window.location.reload();
                }, 100);
                return data;
            }).catch(parseError => {
                // Even if JSON parsing fails, it was successful
                console.log('Course saved but response parse failed');
                alert('Course saved successfully!');
                closeModal();
                setTimeout(() => {
                    window.location.reload();
                }, 100);
            });
        }
        
        // Handle error responses
        return response.json().then(err => {
            console.error('Server error:', err);
            throw new Error(err.message || 'Server error');
        }).catch(parseError => {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        });
    })
    .catch(error => {
        console.error('Fetch error:', error);
        alert('Error saving course: ' + error.message);
    });
}

// Tab switching
window.switchTab = function(tabName) {
    // Hide all tabs
    const allTabs = document.querySelectorAll('.tab-content');
    const allBtns = document.querySelectorAll('.tab-btn');
    
    if (!allTabs.length || !allBtns.length) {
        console.error('Tab elements not found');
        return;
    }
    
    allTabs.forEach(tab => tab.classList.remove('active'));
    allBtns.forEach(btn => btn.classList.remove('active'));
    
    // Show selected tab
    if (tabName === 'courseInfo') {
        const courseInfoTab = document.getElementById('courseInfoTab');
        const courseInfoBtn = document.querySelector('.tab-btn:first-child');
        if (courseInfoTab) courseInfoTab.classList.add('active');
        if (courseInfoBtn) courseInfoBtn.classList.add('active');
    } else if (tabName === 'schedules') {
        const schedulesTab = document.getElementById('schedulesTab');
        const scheduleBtn = document.getElementById('scheduleTabBtn');
        if (schedulesTab) schedulesTab.classList.add('active');
        if (scheduleBtn) scheduleBtn.classList.add('active');
    }
}

// Toggle bulk schedule creation
window.toggleBulkSchedule = function() {
    const isEnabled = document.getElementById('enableBulkSchedule').checked;
    document.getElementById('singleDateSection').style.display = isEnabled ? 'none' : 'block';
    document.getElementById('bulkDateSection').style.display = isEnabled ? 'block' : 'none';
}

// Schedule storage
let courseSchedules = [];
let selectedDates = [];
let timeSlots = [];

// Add date to list
window.addDateToList = function() {
    const dateInput = document.getElementById('date_picker_helper');
    const date = dateInput.value;
    
    if (!date) return;
    
    if (selectedDates.includes(date)) {
        alert('This date is already selected!');
        return;
    }
    
    selectedDates.push(date);
    selectedDates.sort(); // Keep dates in order
    renderSelectedDates();
    dateInput.value = ''; // Clear input
}

// Render selected dates
function renderSelectedDates() {
    const container = document.getElementById('selectedDatesList');
    
    if (selectedDates.length === 0) {
        container.innerHTML = '<small style="color: #999; width: 100%;">Select dates above to add them to the list</small>';
        return;
    }
    
    container.innerHTML = selectedDates.map(date => `
        <span class="date-badge" onclick="removeDateFromList('${date}')">
            📅 ${formatDate(date)} ✕
        </span>
    `).join('');
}

// Remove date from list
window.removeDateFromList = function(date) {
    selectedDates = selectedDates.filter(d => d !== date);
    renderSelectedDates();
}

// Toggle multiple slots
window.toggleMultipleSlots = function() {
    const isEnabled = document.getElementById('multipleSlotsPerDate').checked;
    document.getElementById('singleSlotSection').style.display = isEnabled ? 'none' : 'block';
    document.getElementById('multipleSlotSection').style.display = isEnabled ? 'block' : 'none';
}

// Add time slot
window.addTimeSlot = function() {
    const startTime = document.getElementById('slot_start_time').value;
    const endTime = document.getElementById('slot_end_time').value;
    
    if (!startTime || !endTime) {
        alert('Please enter both start and end times');
        return;
    }
    
    if (startTime >= endTime) {
        alert('End time must be after start time');
        return;
    }
    
    timeSlots.push({ start_time: startTime, end_time: endTime });
    renderTimeSlots();
    
    // Clear inputs
    document.getElementById('slot_start_time').value = '';
    document.getElementById('slot_end_time').value = '';
}

// Render time slots
function renderTimeSlots() {
    const container = document.getElementById('timeSlotsList');
    
    if (timeSlots.length === 0) {
        container.innerHTML = '<small style="color: #999;">No time slots added yet</small>';
        return;
    }
    
    container.innerHTML = timeSlots.map((slot, index) => `
        <div class="time-slot-item">
            <span>⏰ ${slot.start_time} - ${slot.end_time}</span>
            <button onclick="removeTimeSlot(${index})">Remove</button>
        </div>
    `).join('');
}

// Remove time slot
window.removeTimeSlot = function(index) {
    timeSlots.splice(index, 1);
    renderTimeSlots();
}

// Add schedule(s)
window.addSchedule = function() {
    const isBulk = document.getElementById('enableBulkSchedule').checked;
    
    if (isBulk) {
        addBulkSchedules();
    } else {
        addSingleSchedule();
    }
}

// Add single schedule
function addSingleSchedule() {
    const date = document.getElementById('schedule_date').value;
    const startTime = document.getElementById('schedule_start_time').value;
    const endTime = document.getElementById('schedule_end_time').value;
    const maxStudents = document.getElementById('schedule_max_students').value;
    const instructorId = document.getElementById('schedule_instructor').value;
    const notes = document.getElementById('schedule_notes').value;
    
    if (!date || !startTime || !endTime) {
        alert('Please fill in all required fields (Date, Start Time, End Time)');
        return;
    }
    
    const schedule = {
        date,
        start_time: startTime,
        end_time: endTime,
        max_students: maxStudents || 1,
        instructor_id: instructorId || null,
        notes: notes || ''
    };
    
    courseSchedules.push(schedule);
    renderSchedules();
    clearScheduleForm();
}

// Add bulk schedules
function addBulkSchedules() {
    const maxStudents = document.getElementById('schedule_max_students').value;
    const instructorId = document.getElementById('schedule_instructor').value;
    const notes = document.getElementById('schedule_notes').value;
    const isMultipleSlots = document.getElementById('multipleSlotsPerDate').checked;
    
    if (selectedDates.length === 0) {
        alert('Please select at least one date');
        return;
    }
    
    let addedCount = 0;
    
    if (isMultipleSlots) {
        // Multiple time slots per date
        if (timeSlots.length === 0) {
            alert('Please add at least one time slot');
            return;
        }
        
        // Create schedules for each date × time slot combination
        selectedDates.forEach(date => {
            timeSlots.forEach(slot => {
                const schedule = {
                    date: date,
                    start_time: slot.start_time,
                    end_time: slot.end_time,
                    max_students: maxStudents || 1,
                    instructor_id: instructorId || null,
                    notes: notes || ''
                };
                
                courseSchedules.push(schedule);
                addedCount++;
            });
        });
    } else {
        // Single time slot for all dates
        const startTime = document.getElementById('bulk_start_time').value;
        const endTime = document.getElementById('bulk_end_time').value;
        
        if (!startTime || !endTime) {
            alert('Please fill in start and end times');
            return;
        }
        
        selectedDates.forEach(date => {
            const schedule = {
                date: date,
                start_time: startTime,
                end_time: endTime,
                max_students: maxStudents || 1,
                instructor_id: instructorId || null,
                notes: notes || ''
            };
            
            courseSchedules.push(schedule);
            addedCount++;
        });
    }
    
    alert(`Added ${addedCount} schedule(s)!`);
    renderSchedules();
    clearScheduleForm();
}

// Render schedules
function renderSchedules() {
    const container = document.getElementById('schedulesContainer');
    const count = document.getElementById('scheduleCount');
    
    count.textContent = courseSchedules.length;
    
    if (courseSchedules.length === 0) {
        container.innerHTML = '<p style="color: #999; text-align: center; padding: 20px;">No schedules added yet</p>';
        return;
    }
    
    // Group schedules by date for better display
    const schedulesByDate = {};
    courseSchedules.forEach((schedule, index) => {
        if (!schedulesByDate[schedule.date]) {
            schedulesByDate[schedule.date] = [];
        }
        schedulesByDate[schedule.date].push({ ...schedule, originalIndex: index });
    });
    
    container.innerHTML = Object.keys(schedulesByDate).sort().map(date => {
        const dateSchedules = schedulesByDate[date];
        return `
            <div style="margin-bottom: 15px; background: #f8f9fa; padding: 12px; border-radius: 6px;">
                <strong style="font-size: 1.1rem;">📅 ${formatDate(date)}</strong>
                ${dateSchedules.map(schedule => `
                    <div class="schedule-item" style="margin: 8px 0;">
                        <div class="schedule-item-details">
                            ⏰ ${schedule.start_time} - ${schedule.end_time} | 
                            👥 Max: ${schedule.max_students} students
                            ${schedule.notes ? '<br><small>📝 ' + schedule.notes + '</small>' : ''}
                        </div>
                        <div class="schedule-item-actions">
                            <button onclick="removeSchedule(${schedule.originalIndex})">Remove</button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }).join('');
}

// Remove schedule
window.removeSchedule = function(index) {
    courseSchedules.splice(index, 1);
    renderSchedules();
}

// Clear schedule form
function clearScheduleForm() {
    document.getElementById('schedule_date').value = '';
    document.getElementById('schedule_start_time').value = '';
    document.getElementById('schedule_end_time').value = '';
    document.getElementById('date_picker_helper').value = '';
    document.getElementById('bulk_start_time').value = '';
    document.getElementById('bulk_end_time').value = '';
    document.getElementById('slot_start_time').value = '';
    document.getElementById('slot_end_time').value = '';
    document.getElementById('schedule_notes').value = '';
    
    // Reset selected dates and time slots
    selectedDates = [];
    timeSlots = [];
    renderSelectedDates();
    renderTimeSlots();
    
    // Uncheck checkboxes
    document.getElementById('enableBulkSchedule').checked = false;
    document.getElementById('multipleSlotsPerDate').checked = false;
    toggleBulkSchedule();
    toggleMultipleSlots();
}

// Format date for display
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
}

// Override saveCourse to include schedules
const originalSaveCourse = window.saveCourse;
window.saveCourse = function(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const id = document.getElementById('courseId').value;
    const url = id 
        ? `/${schoolSlug}/admin/courses/${id}`
        : `/${schoolSlug}/admin/courses`;
    
    const data = {};
    formData.forEach((value, key) => {
        // Skip empty values for optional fields
        if (key === 'max_students' && !value) {
            return;
        }
        data[key] = value;
    });
    
    // Add schedules
    data.schedules = courseSchedules;
    
    if (id) data._method = 'PUT';
    
    // Validate required fields
    if (!data.title || !data.price || !data.duration_hours) {
        alert('Please fill in all required fields (Title, Price, Duration)');
        return;
    }
    
    // Get CSRF token
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
    
    if (!csrfToken) {
        console.error('CSRF token not found');
        alert('Security token missing. Please refresh the page and try again.');
        return;
    }
    
    console.log('Saving course:', { url, data, hasSchedules: data.schedules?.length || 0 });
    
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken,
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        console.log('Response status:', response.status);
        
        if (!response.ok) {
            return response.json().then(err => {
                throw new Error(err.message || `HTTP ${response.status}: ${response.statusText}`);
            }).catch(parseError => {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            });
        }
        
        return response.json();
    })
    .then(data => {
        console.log('Success response:', data);
        
        if (data.success) {
            const scheduleMsg = courseSchedules.length > 0 
                ? ` with ${courseSchedules.length} schedule(s)` 
                : '';
            alert('Course saved successfully' + scheduleMsg + '!');
            
            // Reset schedules
            courseSchedules = [];
            selectedDates = [];
            timeSlots = [];
            
            // Close modal
            closeModal();
            
            // Reload page
            setTimeout(() => {
                window.location.reload();
            }, 100);
        } else {
            throw new Error(data.message || 'Unknown error occurred');
        }
    })
    .catch(error => {
        console.error('Error saving course:', error);
        alert('Error saving course: ' + error.message);
    });
}
</script>
@endsection